<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>.:USER:.</title>
<?php
	include_once("dbconnect.php");
	include_once("SessionCheck.php");
	include_once("LoadScript.php");
	include_once("javascripts.php");
	//echo "WELCOME TO ".$_SESSION["username"];
	//echo $_REQUEST["UR"] ; //exit;
	if(isset($_REQUEST['Action']) =='DeleteSelected')
	{
		$id = $_POST['pk_list'];
		$idList = implode("','", $id);
		$strDel = "DELETE FROM user WHERE UserID IN ('". $idList . "')";	
		mysql_query($strDel);
		echo "<script>location:Candidate.php</script>";
	}
	if(isset($_REQUEST["UR"]))
	{
		$a=$_REQUEST["UR"];
		$at=$_REQUEST["AT"];
		$strup="update user set IsActive='$a' where UserID='$at'";
		//echo $strup;
		mysql_query($strup);
		//echo "<script>location:UserList.php</script>";
		header("location:Candidate.php");
	}
	
	$str = "select * from user where IsCandidate=1";
	$res = mysql_query($str);
	$recordcount = mysql_num_rows($res);
	$page = $_SERVER['PHP_SELF'];
?>
</head>
<body><table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  		<tr>
   			 <td width="1002"><?php include("Header.php");?></td>
  		</tr>
  		<tr>
 			<td bgcolor="#FFFFFF">
  				<table width="100%" cellspacing="0" cellpadding="0">
   					 <tr>
                        <td height="10px"></td>
                     </tr>
        </tr>
         <tr>
              <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
              <td width="972" valign="top">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                           <td width="972">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="10">&nbsp;</td>
                                        <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                                        <td width="10">&nbsp;</td>
                                        <td valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td height="5"></td>
                                                  </tr>
                                                  <tr>
                                                  <td>
          <table width="100%"  cellspacing="0" cellpadding="0">
            <tr>
              <td width="712" class="product-links" style="padding-left:8px;">UserList</td>
            </tr>
            <tr>
              <td><form id="frmStdForm" name="frmStdForm" method="post">
                  <table id="tblAddEditButtons">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    
                  </table>
                  <table id="tblGrid" cellpadding="0" cellspacing="0"  align="center">
                    <tr>
                      <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                      <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                      <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                    </tr>
                    <tr>
                      <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                      <td ><table width="670" >
                          <tr class="product1">
						   <?php
							 if($_SESSION["ISDelete"]==1)
							 {
							 ?>
                            <td class="myHlable" align="center" width="8"></td>
							 <?php }?>
                            <td class="myHlable" align="center">person name</td>
                            <td class="myHlable" align="center">address</td>
							<td class="myHlable" align="center">email id</td>
                             <td class="myHlable" align="center">mobile no</td>
							 
                             <td class="myHlable" align="center">active</td>
							 
                            
							 <td class="myHlable" align="center">view</td>
							 
                          </tr>
                          <?php 
						while($rs = mysql_fetch_object($res))
						{
							?>
                          <tr class="even">
						   <?php
							 if($_SESSION["ISDelete"]==1)
							 {
							 ?>
                           <td width="8"><input type="checkbox" name="pk_list[]" id="pk_list[]" value="<?php echo $rs->UserID; ?>" /></td>
							 <?php } ?>
                            <td class="myllable" align="left"><?php echo $rs->FirstName." ".$rs->LastName;?></td>
                            <td class="myllable" align="left"><?php echo $rs->Address;?></td>
							<td class="myllable" align="left"><?php echo $rs->EmailId;?></td>
                            <td class="myllable" align="left"><?php echo $rs->MobileNo;?></td>
							  
                           <td class="myllable" align="left"><?php 
		if($rs->IsActive==0)
		{
		?>	
		
		<a href="?AT=<?php echo $rs->UserID;?>&&UR=1"><center><img src="buttonimg/wrong.png" class="pointer" alt="View" width="18" height="18" border="0"  title="deactive"/><center></a>
		<?php
		}
		else
		{
		?>
		<a href="?AT=<?php echo $rs->UserID;?>&&UR=0"><center><img src="buttonimg/right.png" class="pointer" alt="View" width="18" height="18" border="0" title="active" /><center></a>
		<?php
		}
		?></td>
		
		
		
		<td align="center"><a href="UserListDec.php?EID=<?php echo $rs->UserID;?>"><img src="images/icon_view.gif" class="pointer" alt="View" width="18" height="18" border="0" title="view" /></a>    
                            
                           </tr>
                          <?php 
							
												}
												?>
                          
                        </table></td>
                      <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                      <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                      <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                    </tr>
                  </table>
				   <?php
							 if($_SESSION["ISDelete"]==1)
							 {
							 ?>
                  <?php  include("navigation.php");?>
							 <?php }?>
            </form>
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
        </table>
        </td>
        
        </tr>
        
      </table>
      </td>
      
      </tr>
      
    </table>
    </td>
    
    <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
    </tr>
  </table>
  </td>
  
  </tr>
  
  <tr>
    <td><?php 
	
	include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
