<?php
$cn=mysql_connect("localhost","root","")or die("Cant Connect with Database Server ".mysql_error());
mysql_select_db("dbnps",$cn)or die("Cant find Specified Database on Server ".mysql_error());
session_start();
?>