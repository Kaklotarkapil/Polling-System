<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>.:City:.</title>
<?php 
	
	include("dbconnect.php");
	include("SessionCheck.php");
	include("LoadScript.php");
	include("javascripts.php");
	
	if(isset($_REQUEST['Action']) =='DeleteSelected')
	{
		$id = $_POST['pk_list'];
		$idList = implode("','", $id);
		$strDel = "DELETE FROM city WHERE CityID IN ('". $idList . "')";	
		mysql_query($strDel);
		echo "<script>location:City.php</script>";
	}
	$str = "select * from city where StateID='".$_SESSION['SID']."'";

	$res = mysql_query($str);
	$recordcount = mysql_num_rows($res);
	
	
?>
</head>
<body><table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  		<tr>
   			 <td width="1002"><?php include("Header.php");?></td>
  		</tr>
  		<tr>
 			<td bgcolor="#FFFFFF">
  				<table width="100%" cellspacing="0" cellpadding="0">
   					 <tr>
                        <td height="10px"></td>
                     </tr>
        </tr>
         <tr>
              <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
              <td width="972" valign="top">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                           <td width="972">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="10">&nbsp;</td>
                                        <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                                        <td width="10">&nbsp;</td>
                                        <td valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td height="5"></td>
                                                  </tr>
                                                  <tr>
                                                  <td>
          <table width="100%"  cellspacing="0" cellpadding="0">
            <tr>
              <td width="712" class="product-links" style="padding-left:8px;">City</td>
            </tr>
            <tr>
              <td><form id="frmStdForm" name="frmStdForm" method="post" >
                  <table id="tblAddEditButtons" align="center">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td align="right" align="center"><button type="button" name="btn_add" class="buttonop" onMouseOver="document.frmStdForm.sub_butadd.src='buttonimg/btn_add.gif';" onMouseOut="document.frmStdForm.sub_butadd.src='buttonimg/btn_add_02.gif';" onClick="location.href='CityAdd.php'" ><img src="buttonimg/btn_add_02.gif" alt="" name="sub_butadd"/></button></td>
                    </tr>
                  </table>
                  <table id="tblGrid" cellpadding="0" cellspacing="0"  align="center">
                    <tr>
                      <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                      <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                      <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                    </tr>
                    <tr>
                      <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                      <td ><table width="400" >
                          <tr class="product1">
                            <td class="myHlable" align="left" width="8"></td>
                               
                             <td class="myHlable" align="center">City name</center></td>
							
                             <td class="myHlable" align="center">edit</td>
                          </tr>
                          <?php 
													while($rs = mysql_fetch_object($res))
													{
												
												?>
                          <tr class="even">
                            <td width="8"><input type="checkbox" name="pk_list[]" id="pk_list[]" value="<?php echo $rs->CityID; ?>" /></td>
                      
                            <td class="myllable" align="center"><center><?php echo $rs->CityName;?></center></td>   
                            <td align="center"><a href="CityEdit.php?EID=<?php echo $rs->CityID;?>"><img src="buttonimg/btn_edit.gif" name="edit" /></a></td>
                           </tr>
                          <?php 
							
												}
												?>
                          
                        </table></td>
                      <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                      <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                      <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                    </tr>
                  </table>
				  <tr>
                                        <td align="center">
                                          <button type="button" name="btn_back" class="buttonop" onClick="javascript:history.go(-1)" onMouseOver="document.frmAdd.sub_butback.src='buttonimg/btn_back.gif';" onMouseOut="document.frmAdd.sub_butback.src='buttonimg/btn_back_02.gif';"onClick="location.href='State.php'" > <img src="buttonimg/btn_back_02.gif" alt="Submit this form" name="sub_butback" /> </button></td>
                                  </tr>
                  
                  <?php  include("navigation.php");?>
            </form>
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
        </table>
        </td>
        
        </tr>
        
      </table>
      </td>
      
      </tr>
      
    </table>
    </td>
    
    <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
    </tr>
  </table>
  </td>
  
  </tr>
  
  <tr>
    <td><?php 
	
	include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
