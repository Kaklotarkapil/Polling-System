<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>.:ADMIN:.</title>
<?php
	include_once("dbconnect.php");
	//include_once("SessionCheck.php");
	include_once("LoadScript.php");
	include_once("javascripts.php");
	
	/*if(isset($_REQUEST['EID']))
	{
		$strup="select * from tbladmin where AdminId=".$_REQUEST['EID']."";
		$stup=mysql_query($strup);
		$rs = mysql_fetch_object($stup);
	}*/
		
	if(isset($_REQUEST["INS"]))
	{
		$strup="update adminpermission set IsInsert='".$_REQUEST["INS"]."' where AdminId='".$_REQUEST["INSERT"]."'";
		$stup=mysql_query($strup);
		header("location:AdminView.php");
	}
	if(isset($_REQUEST["UPD"]))
	{
		$strup="update adminpermission set IsUpdate='".$_REQUEST["UPD"]."' where AdminId='".$_REQUEST["UPDATE"]."'";
		$stup=mysql_query($strup);
		header("location:AdminView.php");
	}
	if(isset($_REQUEST["DELETE"]))
	{
		$strup="update adminpermission set IsDelete='".$_REQUEST["DEL"]."' where AdminId='".$_REQUEST["DELETE"]."'";
		$stup=mysql_query($strup);
		header("location:AdminView.php");
	}
	
	//$str="select * from tbladmin a,tbladminpermission ap where a.AdminId=ap.AdminId and a.AdminId=".$_REQUEST["EID"];
	//$res = mysql_query($str);
	//$rs = mysql_fetch_object($res);
?>
</head>
<body><table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  		<tr>
   			 <td width="1002"><?php include("Header.php");?></td>
  		</tr>
  		<tr>
 			<td bgcolor="#FFFFFF">
  				<table width="100%" cellspacing="0" cellpadding="0">
   					 <tr>
                        <td height="10px"></td>
                     </tr>
        </tr>
         <tr>
              <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
              <td width="972" valign="top">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                           <td width="972">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="10">&nbsp;</td>
                                        <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                                        <td width="10">&nbsp;</td>
                                        <td valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td height="5"></td>
                                                  </tr>
                                                  <tr>
                                                  <td>
          <table width="100%"  cellspacing="0" cellpadding="0">
            <tr>
              <td width="712" class="product-links" style="padding-left:8px;">AdminList</td>
            </tr>
            <tr>
              <td><form id="frmStdForm" name="frmStdForm" method="post">
                  <table id="tblAddEditButtons">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    
                  </table>
                  <table id="tblGrid" cellpadding="0" cellspacing="0"  align="center">
                    <tr>
                      <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                      <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                      <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                    </tr>
                    <tr>
                      <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                      <td ><table width="670" >
                          <tr class="product1">
                            <td class="myHlable" align="left" width="8"></td>
                           
                            <td class="myHlable" align="center">username</td>
                             <td class="myHlable" align="center">email id</td>
			
                             <td class="myHlable" align="center">isinsert</td>
							  <td class="myHlable" align="center">isupdate</td>
							   <td class="myHlable" align="center">isdelete</td>
							 
							 
                          </tr>
						  <?php 
						  $str="select * from admin a, adminpermission ap where a.AdminId=ap.AdminId and a.AdminId=".$_SESSION["EID"];
						  $res=mysql_query($str);
						  $rs=mysql_fetch_object($res)
						  ?>
						  
                          
                          <tr class="even">
                           <td width="8"><input type="checkbox" name="pk_list[]" id="pk_list[]" value="<?php echo $rs->AdminId; ?>" /></td>
                            
                            <td class="myllable" align="left"><center><?php echo $rs->FirstName;?></center></td>
							 <td class="myllable" align="left"><center><?php echo $rs->Email_Id;?></center></td>
							 
							 <td class="myllable" align="left"><center><?php if($rs->IsInsert==1)
																			 {
																				 ?><a href="?INSERT=<?php echo $rs->AdminId;?>&INS=0"><img src="buttonimg/right.png" width=15></a>
																				 <?php
																			 }
																			 else
																			 {
																				 ?><a href="?INSERT=<?php echo $rs->AdminId;?>&INS=1"><img src="buttonimg/wrong.png" width=15></a>
																				 <?php
																			 }	 
																			 ?>
																</center></td>
							 <td class="myllable" align="left"><center><?php if($rs->IsUpdate==1)
																			 {
																				 ?><a href="?UPDATE=<?php echo $rs->AdminId;?>&UPD=0"><img src="buttonimg/right.png" width=15></a>
																				 <?php
																			 }
																			 else
																			 {
																				 ?><a href="?UPDATE=<?php echo $rs->AdminId;?>&UPD=1"><img src="buttonimg/wrong.png" width=15></a>
																				 <?php
																			 }	 
																			 ?></center></td>
							 <td class="myllable" align="left"><center><?php if($rs->IsDelete==1)
																			 {
																				 ?><a href="?DELETE=<?php echo $rs->AdminId;?>&DELSSS=0"><img src="buttonimg/right.png" width=15></a>
																				 <?php
																			 }
																			 else
																			 {
																				 ?><a href="?DELETE=<?php echo $rs->AdminId;?>&DEL=1"><img src="buttonimg/wrong.png" width=15></a>
																				 <?php
																			 }	 
																			 ?></center></td>
																				
							                  
                        </table></td>
						
                      <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                      <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                      <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                    </tr>
                  </table>
                  <?php  include("navigation.php");?>
            </form>
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
        </table>
        </td>
        
        </tr>
        
      </table>
      </td>
      
      </tr>
      
    </table>
    </td>
    
    <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
    </tr>
  </table>
  </td>
  
  </tr>
  
  <tr>
    <td><?php 
	
	include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
