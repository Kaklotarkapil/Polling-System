<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>Change Password</title>

<script src="JavaScriptFunctions.js" language="javascript"></script>
<script type="text/javascript" language="javascript">
	function frmValidation()
	{
		if(document.getElementById('txtoPassword').value =="")
		{
			 alert("Please Enter oldPassword.");
		      return false;
		}
		
		 if(document.getElementById('txtPassword').value =="")
		{
			 alert("Please Enter Password.");
		      return false;
		}
	 if(document.getElementById('txtRePassword').value =="")
		{
			 alert("Please Enter Re-TypePassword.");
		      return false;
		}
		
		else
		{
			return true;
		}
	}
	
</script>


<?php 
	include("LoadScript.php");
	include("dbconnect.php");
	include("sessioncheck.php");
		include("javascripts.php");
	
?>
</head>
<link rel="stylesheet" href="dhtmlgoodies_calendar.css?random=20051112" media="screen">
</link>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="dhtmlgoodies_calendar.js?random=20051112"></script>
<body>
<table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="1002"><?php include("Header.php");?></td>
  </tr>
  <tr>
  
  <td bgcolor="#FFFFFF"><table width="100%" cellspacing="0" cellpadding="0">
      <tr>
      <tr>
        <td height="10px"></td>
      </tr>
      </tr>
      
      <tr>
        <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
        <td width="972" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="972"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="10">&nbsp;</td>
                    <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                    <td width="10">&nbsp;</td>
                    <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="5"></td>
                        </tr>
                        <tr>
                          <td>
                           <?php
						  if(isset($_REQUEST['btn_save']))
						  {
							$strQ = "select * from admin where UserName= '".$_SESSION['UserName']."'";	
				
				$rs = mysql_query($strQ);
				$res = mysql_fetch_object($rs);
				//$ans = base64_decode(trim($res->Password));
				$ans = trim($res->Password); 				
					
				if( $ans == trim($_REQUEST['txtOldPassword']))
				{
							//echo "kapil";
						  //$str="update admin set Password='".base64_encode($_REQUEST['txtPassword'])."' where UserName='".$_SESSION["UserName"]."'";
						 $str="update admin set Password='".$_REQUEST['txtPassword']."' where UserName='".$_SESSION["UserName"]."'";
						  mysql_query($str);
						  
						  echo "<script>location.href='UserList.php';</script>";
						  }
						  }
						  ?>
                         	
                            <table width="100%"  cellspacing="0" cellpadding="0">
                             <tr>
              <td width="712" align="center" class="product-links" style="padding-left:8px;"> Change Password</td>
            </tr>
            <tr>
              <td>
              <form id="frmAdd" name="frmAdd" method="post" onsubmit="return frmValidation();">
                <table id="tblSpacer" >
                  <tr>
                    <td height="10px"></td>
                  </tr>
                  
                 
                </table>
                <table id="tblAdd" width="50%"  cellpadding="0" cellspacing="0"  align="center">
                  <tr>
                    <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                    <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                    <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                  </tr>
                  <tr>
                   
                           				
                  
                  <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                  <td >
                  <table >
                    <tr>
                      <td class="cssLabel">Old Password:</td>
                      <td align="left" ><input type="Password"id="txtoPassword"  name="txtOldPassword"class="inputTextBoxPwd"  onblur="ValidateControl('txtoPassword','errMsgpwd','Password');" /></td>
                    </tr>
                    <tr>
                      <td height="3px"></td>
                      <td><label id="errMsgpwd" class="cssError"></label></td>
                    </tr>
                    <tr>
                      <td class="cssLabel">New Password:</td>
                      <td align="left" ><input type="Password" class="inputTextBoxPwd" id="txtPassword" name="txtPassword" onblur="ValidateControl('txtPassword','errMsgNpwd','NewPassword');" /></td>
                    </td>
                    
                    </tr>
                    
                    <tr>
                      <td height="3px"></td>
                      <td><label id="errMsgNpwd" class="cssError"></label></td>
                    </tr>
                    <tr>
                      <td class="cssLabel">Re-Type NewPassword:</td>
                      <td align="left" ><input type="Password" class="inputTextBoxPwd" id="txtRePassword" onblur="PasswordChecking('errMsgRepwd');ValidateControl('txtRePassword','errMsgRepwd','Re-type Password')" /></td>
                    </tr>
                    <tr>
                      <td height="3px"></td>
                      <td><label id="errMsgRepwd" class="cssError"></label></td>
                    </tr>                                                           
                                          </table></td>
                                        <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                                      </tr>
                                      <tr>
                                        <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                                        <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                                        <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                                      </tr>
                                    </table>
                                    <tr>
                                        <td align="center"><button type="submit" name="btn_save" class="buttonop" onMouseOver="document.frmList.sub_butsave.src='buttonimg/btn_save.gif';" onMouseOut="document.frmList.sub_butsave.src='buttonimg/btn_save_02.gif';" > <img src="buttonimg/btn_save.gif" alt="Submit this form" name="sub_butsave"/> </button>
                                          <button type="button" name="btn_back" class="buttonop" onClick="javascript:history.go(-1)" onMouseOver="document.frmList.sub_butback.src='buttonimg/btn_back.gif';" onMouseOut="document.frmList.sub_butback.src='buttonimg/btn_back_02.gif';"> <img src="buttonimg/btn_back.gif" alt="Submit this form" name="sub_butback" /> </button></td>
                                  </form></td>
                              </tr>
                            </table></td>
                        </tr>
                      </table></td>
                  </tr>
                </table></td>
            </tr>
          </table></td>
        <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td><?php include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
