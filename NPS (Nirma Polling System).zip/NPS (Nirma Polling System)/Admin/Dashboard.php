
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />

<title>Dashbord</title>
<?php
	include_once("dbconnect.php");
	//include_once("SessionCheck.php");
	include_once("LoadScript.php");
	include_once("javascripts.php");
?>
</head>

<body>



<table width="1002" border="0" align="center"  style="font-family:calibri;color:#666;" cellpadding="0" cellspacing="0">
  		<tr>
   			 <td width="1002"><?php include("Header.php");?></td>
  		</tr>
  		<tr>
 			<td bgcolor="#FFFFFF">
  				<table width="100%" cellspacing="0" cellpadding="0">
   					 <tr>
                        <td height="10px"></td>
                     </tr>
        </tr>
         <tr>
              <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
              <td width="972" valign="top">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                           <td width="972">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="10">&nbsp;</td>
                                        <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                                        <td width="10">&nbsp;</td>
                                        <td valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td height="5"></td>
                                                  </tr>
                                                  <tr>
                                                  <td>
          <table width="100%"  cellspacing="0" cellpadding="0">
            <tr>
              <td width="712" class="product-links" style="padding-left:8px;">DASHBORD</td>
            </tr>
            <tr>
              <td><form id="frmStdForm" name="frmStdForm" method="post">
                  <table id="tblAddEditButtons">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    
                  </table>
                  <table id="tblGrid" cellpadding="0" cellspacing="0"  align="center">
                    <tr>
                      <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                      <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                      <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                    </tr>
                    <tr>
                      <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                      <td >
					 
				<div style="padding:20px;">
					 <div class="desh">
					 
					 
					 
						<div class="col-md-4" style="padding:26px;margin-left:18px; border:5px solid gray; float:left;background-color: white Darker; border-radius:10px 10px 10px 10px ;">
								<table><tr><td><b><u>Total Admin</u></b></td>
									<td>
									<?php 
										$admin="select count(*) as cnt from admin";
										 $rsadmin=mysql_query($admin);
										 $resadmin=mysql_fetch_object($rsadmin);
										echo $resadmin->cnt;
									?></td></tr>
								
									
									<tr><td><b>Super Admin</b></td>
									<td><?php 
										$count="select count(*) as cnt from admin where IsSuperAdmin=1";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?>  </td></tr>
									
									<tr><td><b>Sub Admin</b></td><td>
									<?php 
										$count="select count(*) as cnt from admin where IsSuperAdmin=0";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										   echo $obj->cnt;
									?>  </td></tr>
									</table>
									
						</div>
							
						<div class="col-md-4" style="padding:26px;margin-left:34px; border:5px solid gray; float:left; background-color: white Darker; border-radius:10px 10px 10px 10px ;">			
									<table><tr><td><b><u>Total User</u></b></td>
									<td>
									<?php 
										$user="select count(*) as cnt from  user";
										 $rsuser=mysql_query($user);
										 $resuser=mysql_fetch_object($rsuser);
										echo $resuser->cnt;
									?> </td></tr>
 
									
									<tr><td><b>Active</b></td>
									<td><?php 
										$count="select count(*) as cnt from user where IsActive=1";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?>  </td></tr>
									<tr><td><b>Deactive</b></td>
									<td><?php 
										$count="select count(*) as cnt from user where IsActive=0";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										   echo $obj->cnt;
									?>  </td></tr>
									</table>
						</div>
							
						<div class="col-md-4" style="padding:26px;margin-left:37px; border:5px solid gray; float:left;background-color: white Darker; border-radius:10px 10px 10px 10px ;">		  
									<table><tr><td><b><u>User & Candidate</u></b></td>
									<td>
									<?php 
										$count="select count(*) as cnt from user ";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?> </td></tr>
 
									
									<tr><td><b>Voter</b></td>
									<td><?php 
										$count="select count(*) as cnt from user where IsCandidate=0 ";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?>  </td></tr>
									<tr><td><b>Candidate</b></td>
									<td><?php 
										$count="select count(*) as cnt from user where IsCandidate=1 ";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?>  </td></tr>
									</table>
						</div>
				
						
						<div class="col-md-4" style="padding:25px;margin-left:-3px; border:5px solid gray; float:left; background-color: white Darker;margin-top:25px;margin-left:18px; border-radius:10px 10px 10px 10px ;">
									<table><tr><td><b><u>Total Post</u></b></td>
									<td>
									<?php 
										$admin="select count(*) as cnt from post";
										 $rsadmin=mysql_query($admin);
										 $resadmin=mysql_fetch_object($rsadmin);
										echo $resadmin->cnt;
									?> </td></tr>
 
									
									<tr><td><b><u>Total Votes</u></</b></td>
									<td>
									<?php 
										$count="select count(*) as cnt from vote";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										echo $obj->cnt;
									?>  </td></tr>
								
									
									
									
									</table>
						</div>
						
						<div class="col-md-4" style="padding:25px;margin-left:150px;border:5px solid gray; float:left; background-color: white Darker;margin-top:25px; border-radius:10px 10px 10px 10px ;">
									<table><tr><td><b><u><h2>Vote Percentage</h2></u></b></td>
									<td>
									<?php 
									$count="select count(*) as cnt from vote";
										 $result=mysql_query($count);
										 $obj=mysql_fetch_object($result);
										//echo $obj->cnt;
										//$total=(90*100)/100;
										$percentage=($obj->cnt * 100)/160;
										echo "<h2>".$percentage."%</h2>";
										
									?> </td></tr>
									</table>
						</div>
							
						
						
							
						
					</div>
				</div>
					  
					
						
				
				
					 <table width="670" >
					
					 
							</table>
							
							</td>
                      <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                      <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                      <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                    </tr>
                  </table>
             
            </form>
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
        </table>
        </td>
        
        </tr>
        
      </table>
      </td>
      
      </tr>
      
    </table>
    </td>
    
    <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
    </tr>
  </table>
  </td>
  
  </tr>
  
  <tr>
    <td><?php 
	
	include("Footer.php");?>
</td>
</tr>
</table>

</body>
</html>
