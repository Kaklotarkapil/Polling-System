<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>.:ADMIN:.</title>
<?php
	include_once("dbconnect.php");
	include_once("SessionCheck.php");
	include_once("LoadScript.php");
	include_once("javascripts.php");
	
	if(isset($_REQUEST["EID"]))
	{
		$_SESSION["EID"]=$_REQUEST["EID"];
		header("location:AdminView.php");
	}
	if(isset($_REQUEST['Action']) =='DeleteSelected')
	{
		$id = $_POST['pk_list'];
		$idList = implode("','", $id);
		$strDel = "DELETE FROM admin WHERE AdminId IN ('". $idList . "')";	
		mysql_query($strDel);
		header("location:Admin.php");
		//echo "<script>location:UserList.php</script>";
	}
	if(isset($_REQUEST["UR"]))
	{
		$a=$_REQUEST["UR"];
		$at=$_REQUEST["AT"];
		$strup="update admin set IsActive='$a' where AdminId='$at'";
		//echo $strup;
		mysql_query($strup);
	}
	$str = "select * from admin where IsSuperAdmin=0";
	$res = mysql_query($str);
	$recordcount = mysql_num_rows($res);
	$page = $_SERVER['PHP_SELF'];
?>
</head>
<body><table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  		<tr>
   			 <td width="1002"><?php include("Header.php");?></td>
  		</tr>
  		<tr>
 			<td bgcolor="#FFFFFF">
  				<table width="100%" cellspacing="0" cellpadding="0">
   					 <tr>
                        <td height="10px"></td>
                     </tr>
        </tr>
         <tr>
              <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
              <td width="972" valign="top">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                           <td width="972">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="10">&nbsp;</td>
                                        <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                                        <td width="10">&nbsp;</td>
                                        <td valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td height="5"></td>
                                                  </tr>
                                                  <tr>
                                                  <td>
          <table width="100%"  cellspacing="0" cellpadding="0">
            <tr>
              <td width="712" class="product-links" style="padding-left:8px;">AdminList</td>
            </tr>
            <tr>
              <td><form id="frmStdForm" name="frmStdForm" method="post">
                  <table id="tblAddEditButtons">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                     <tr>
					 
                      
					<?php 
					if($_SESSION["IsInsert"]==1)
					{
					?>	
					
					<td align="right"><button type="button" name="btn_add" class="buttonop" onMouseOver="document.frmStdForm.sub_butadd.src='buttonimg/btn_add.gif';" onMouseOut="document.frmStdForm.sub_butadd.src='buttonimg/btn_add_02.gif';" onClick="location.href='AdminAdd.php'" ><img src="buttonimg/btn_add_02.gif" alt="" name="sub_butadd"/></button></td>	
					<?php
					}
					?>
					
				   </tr> 
                  </table>
				  
                  <table id="tblGrid" cellpadding="0" cellspacing="0"  align="center">
				  
                    <tr>
                      <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                      <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                      <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                    </tr>
					
                    <tr>
                      <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                      <td ><table width="670" >
                          <tr class="product1">
                            <td class="myHlable" align="left" width="8"></td>
                           
                            <td class="myHlable" align="center">person name</td>
                             <td class="myHlable" align="center">email id</td>
							 <!--<td class="myHlable" align="center">created on</td>-->
							 <td class="myHlable" align="center">created by</td>
                             <td class="myHlable" align="center">active</td>
							  <td class="myHlable" align="center">view</td>
							 
                          </tr>
                          <?php 
						  /*$str="select *,CONCAT(a2.FirstName,' ',a2.LastName) as fn from admin a1,admin a2 where a1.CreatedBy=a2.AdminId and a1.IsSuperAdmin=0";*/
              $str ="select *,CONCAT(FirstName,LastName) as fn from admin where IsSuperAdmin=0";
						  
						  $res=mysql_query($str);

						while($rs = mysql_fetch_object($res))
						{
              //echo "$rs";
							?>
                          <tr class="even">
                           <td width="8"><input type="checkbox" name="pk_list[]" id="pk_list[]" value="<?php echo $rs->AdminId; ?>" /></td>
                            
                           <td class="myllable" align="left"><?php echo $rs->FirstName." ".$rs->LastName;?></td>
							 <td class="myllable" align="left"><?php echo $rs->Email_Id;?></td>
							
							 <td class="myllable" align="left"><?php echo $rs->fn;?></td>
							 <td class="myllable" align="left"><center><?php 
									if($rs->IsActive==0)
									{
									?>	
									
									<a href="?AT=<?php echo $rs->AdminId;?>&&UR=1"><center><img src="buttonimg/wrong.png" class="pointer" alt="View" width="18" height="18" border="0"  title="deactive"/><center></a>
									<?php
									}
									else
									{
									?>
									<a href="?AT=<?php echo $rs->AdminId;?>&&UR=0"><center><img src="buttonimg/right.png" class="pointer" alt="View" width="18" height="18" border="0" title="active" /><center></a>
									<?php
									}
									?></center></td>
									<td align="center"><a href="?EID=<?php echo $rs->AdminId;?>"><img src="images/icon_view.gif" class="pointer" alt="View" width="18" height="18" border="0" title="view" /></a>
									
                           </tr>
                          <?php 
							}
							?>
	                      
                        </table></td>
                      <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                      <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                      <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                    </tr>
                  </table>
                  <?php  include("navigation.php");?>
				  
            </form>
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
        </table>
        </td>
        
        </tr>
        
      </table>
      </td>
      
      </tr>
      
    </table>
    </td>
    
    <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
    </tr>
  </table>
  </td>
  
  </tr>
  
  <tr>
    <td><?php 
	
	include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
