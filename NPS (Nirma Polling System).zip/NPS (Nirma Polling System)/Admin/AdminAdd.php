<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/carplus.css" rel="stylesheet" type="text/css" />
<title>Admin</title>
<script src="JavaScriptFunctions.js" language="javascript"></script>
<script type="text/javascript" language="javascript">
	function frmValidation()
	{
		if(document.getElementById('txtFirstName').value =="")
		{
			 alert("Please Enter FirstName.");
		      return false;
		}
		if(document.getElementById('txtLastName').value =="")
		{
			 alert("Please Enter LastName.");
		      return false;
		}
		if(document.getElementById('txtUserName').value =="")
		{
			 alert("Please Enter UserName.");
		      return false;
		}
		if(document.getElementById('txtEMailID').value =="")
		{
			 alert("Please Enter EMailID.");
		      return false;
		}
		if(document.getElementById('txtPassword').value =="")
		{
			 alert("Please Enter Password.");
		      return false;
		}
		if(document.getElementById('txtConfirmPassword').value =="")
		{
			 alert("Please Enter ConfirmPassword.");
		      return false;
		}
		if(document.getElementById('txtAdminID').value =="")
		{
			 alert("Please Enter AdminId.");
		      return false;
		}
		
		else
		{
			
			return true;
		}
		
	}
	
	
</script>
<?php 
	include("dbconnect.php");
	include("LoadScript.php");
	include("sessioncheck.php");
	include("javascripts.php");
if(isset($_REQUEST["AdminEDIT"]))
{
	$sel="select * from admin where AdminId=".$_REQUEST["AdminEDIT"];
	echo $sel;exit;
	$ssel=mysql_query($sel);
	$rr=mysql_fetch_object($ssel);
}
if(isset($_REQUEST["btn_save"]))
{
	if(isset($_REQUEST["AdminEDIT"]))
	{
		$ins="update admin set FirstName='".$_REQUEST["txtFirstName"]."',LastName='".$_REQUEST["txtLastName"]."' where AdminId=".$_REQUEST["AdminEDIT"];
	}
	else
	{
		//if($_REQUEST["txtPassword"]!=$_REQUEST["txtConfirmPassword"])
		//{
			//echo "Enter Confirm Password";
		//}
		//else
		//{
			
			if(isset($_REQUEST["insert"]))
			{
				$insert=1;
			}
			else
			{
				$insert=0;
			}
			if(isset($_REQUEST["update"]))
			{
				$update=1;
			}
			else
			{
				$update=0;
			}
			if(isset($_REQUEST["delete"]))
			{
				$delete=1;
			}
			else
			{
				$delete=0;
			}
			$str1 = "SELECT Email_Id FROM admin where Email_Id='".$_REQUEST["txtEmail"]."'";
			//echo $str;exit;
			$res1 = mysql_query($str1);
			if(mysql_num_rows($res1)==0)
			{
				$pas=base64_encode($_REQUEST["txtpasswd"]);
				$ins="insert into admin values(null,'".$_REQUEST["txtfname"]."','".$_REQUEST["txtlname"]."','".$_REQUEST["txtuname"]."','".$_REQUEST["txtEmail"]."','$pas',now(),'".$_SESSION["AdminID"]."',0,1)";
				//echo $ins;
				$rsup=mysql_query($ins);
				$aaid=mysql_insert_id();
				$strper="insert into adminpermission values(null,'$aaid','$insert','$update','$delete')";
				$rsper=mysql_query($strper);
				header("location:Admin.php");
			}
			else
			{
			//echo "yes";exit;
				echo "<script>alert('Admin already exist');</script>";
				header("location:Admin.php");
			}
		//} 
	}
}
?>


</head>
<link rel="stylesheet" href="dhtmlgoodies_calendar.css?random=20051112" media="screen">
</link>
<script type="text/javascript" src="dhtmlgoodies_calendar.js?random=20051112"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />

<body>
<table width="1002" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="1002"><?php include("Header.php");?></td>
  </tr>
  <tr>
  
  <td bgcolor="#FFFFFF"><table width="100%" cellspacing="0" cellpadding="0">
      <tr>
      <tr>
        <td height="10px"></td>
      </tr>
      </tr>
      
      <tr>
        <td width="15"><img src="images/body-left01.jpg" width="15" height="560" /></td>
        <td width="972" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="972"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="10">&nbsp;</td>
                    <td width="240" valign="top"><?php include("LeftMenu.php");?></td>
                    <td width="10">&nbsp;</td>
                    <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="5"></td>
                        </tr>
                        <tr>
                          <td>
                            <table width="100%"  cellspacing="0" cellpadding="0">
                           
                              <tr>
                                <td width="712" class="product-links" style="padding-left:8px;">Add Admin </td>
                              </tr>
                              </table>
                               <table width="50%"  align="center" cellspacing="0" cellpadding="0">
                              <tr>
                                <td><form id="frmAdd" name="frmAdd"  enctype="multipart/form-data" method="post" onsubmit=" return frmValidation();">
                                    <table id="tblSpacer" >
                                      <tr>
                                        <td height="10px"></td>
                                      </tr>
                                    </table>
                                    <table id="tblAdd" width="100%"  cellpadding="0" cellspacing="0"  align="center">
                                      <tr>
                                        <td align="left" width="10"><img src="TableImages/table_r1_c1.gif" alt="a" style="vertical-align: bottom" /></td>
                                        <td style="background: url(TableImages/table_r1_c2.gif) repeat-x bottom;" ></td>
                                        <td align="left"><img src="TableImages/table_r1_c3.gif" alt="1" style="vertical-align: bottom" /></td>
                                      </tr>
                                      <tr>
                                        <td style="background: url(TableImages/table_r2_c1.gif) repeat-y left;"></td>
                                        <td ><table>
                                    <tr>
                                        <tr>
                                              <td class="cssLabel">First Name:</td>
                                              <td align="left" ><input type="text" name="txtfname"   id="txtFirstName" onblur="ValidateControl('txtFirstName','errMsgFirstName','FirstName')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgFirstName" class="cssError"></label></td>
                                            </tr>
                                          <tr>
                                              <td class="cssLabel">Last Name:</td>
                                              <td align="left" ><input type="text" name="txtlname"   id="txtLastName" onblur="ValidateControl('txtLastName','errMsgLastName','LastName')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgLastName" class="cssError"></label></td>
                                            </tr>
											<tr>
                                              <td class="cssLabel">User Name:</td>
                                              <td align="left" ><input type="text" name="txtuname"   id="txtUserName" onblur="ValidateControl('txtUserName','errMsgUserName','UserName')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgUserName" class="cssError"></label></td>
                                            </tr>
                                          <tr>
                                              <td class="cssLabel">EmailID:</td>
                                              <td align="left" ><input type="text" name="txtEmail" value="<?php if(isset($row))echo $row->Email_Id;?>"  id="txtEMailID" onblur="ValidateControl('txtEMailID','errMsgEMailID','EMailID')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgEMailID" class="cssError"></label></td>
                                            </tr>
                                          <tr>
                                              <td class="cssLabel">Password:</td>
                                              <td align="left" ><input type="password" name="txtpasswd"   id="txtPassword" onblur="ValidateControl('txtPassword','errMsgPassword','Password')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgPassword" class="cssError"></label></td>
                                            </tr>
                                           <tr>
                                              <td class="cssLabel"> Confirm Password:</td>
                                              <td align="left" ><input type="password" name="txtconpasswd"   id="txtConfirmPassword" onblur="ValidateControl('txtConfirmPassword','errMsgtxtPassword','ConfirmPassword')" class="inputTextFile"  /></td>   
                                    </tr>
                                     <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgtxtPassword" class="cssError"></label></td>
                                            </tr>
											<tr>
												<td class="cssLabel"> Insert:</td>
												<td><input type="checkbox" name="insert" /></td>
											</tr>
											<tr>
												<td class="cssLabel"> Update:</td>
												<td><input type="checkbox" name="update" /></td>
											</tr>
											<tr>
												<td class="cssLabel">Delete:</td>
												<td><input type="checkbox" name="delete" /></td>
											</tr>
									 <tr>
                                              <td height="3px"></td>
                                              <td><label id="errMsgtxtPassword" class="cssError"></label></td>
                                            </tr>
															 
                                         
                                           
                                    </tr>
                                   
                                   
                                   
                                   
                                           
                                    </tr>
                                          </table></td>
                                        <td style="background: url(TableImages/table_r2_c3.gif) repeat-y left;"></td>
                                      </tr>
                                      <tr>
                                        <td width="10"><img src="TableImages/table_r3_c1.gif" alt="1" style="vertical-align: top" /></td>
                                        <td style="background: url(TableImages/table_r3_c2.gif) repeat-x top left;" align="left"></td>
                                        <td><img src="TableImages/table_r3_c3.gif" alt="a" style="vertical-align: top" /></td>
                                      </tr>
                                    </table>
                                    <tr>
                                        <td align="center"><button type="submit" name="btn_save" class="buttonop" onMouseOver="document.frmList.sub_butsave.src='buttonimg/btn_save.gif';" onMouseOut="document.frmList.sub_butsave.src='buttonimg/btn_save_02.gif';" > <img src="buttonimg/btn_save.gif" alt="Submit this form" name="sub_butsave"/> </button>
                                          <button type="button" name="btn_back" class="buttonop" onClick="javascript:history.go(-1)" onMouseOver="document.frmList.sub_butback.src='buttonimg/btn_back.gif';" onMouseOut="document.frmList.sub_butback.src='buttonimg/btn_back_02.gif';"> <img src="buttonimg/btn_back.gif" alt="Submit this form" name="sub_butback" /> </button></td>
                                  </form></td>
                              </tr>
                            </table></td>
                        </tr>
                      </table></td>
                  </tr>
                </table></td>
            </tr>
          </table></td>
        <td width="15"><img src="images/body-right01.jpg" width="15" height="560" /></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td><?php include("Footer.php");?>
</td>
</tr>
</table>
</body>
</html>
